#define SDL_MAIN_HANDLED

#ifdef WIN32
#include "windows.h"
#endif

#include <conio.h>
#include <fstream>
using namespace std;

#include "subroutine.h"

int main(void)
{
	double total_time = 0.0;
	int state = 0;
	for (int k = 0; k < 50; k++) {
		total_time += subroutine(&state);
		if (state > 0)
			break;
	}
	if (state == 0) {
		printf("Gesamtzeit %f\n", total_time);
		printf("PRESS ANY KEY!\r\n");
		while (!_kbhit());
		_getch();
		exit(0);
	}
	else
	{
		printf("Fehler");
		printf("PRESS ANY KEY!\r\n");
		while (!_kbhit());
		_getch();
		exit(1);
	}
}